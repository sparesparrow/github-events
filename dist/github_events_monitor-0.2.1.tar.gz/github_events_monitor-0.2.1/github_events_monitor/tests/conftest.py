# Ensure pytest-asyncio plugin is loaded for async tests and fixtures
pytest_plugins = ("pytest_asyncio",)
